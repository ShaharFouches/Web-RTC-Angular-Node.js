const { Server } = require("socket.io");
let io;

const rooms = {};


module.exports.initIO = (httpServer) => {
  io = new Server(httpServer);

  io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);
  
    socket.on('join', ({ roomName }) => {
      console.log(`${socket.id} joined room: ${roomName}`);
      
      if (!rooms[roomName]) {
        rooms[roomName] = [];
      }
  
      rooms[roomName].push(socket.id);
      console.log(`------${rooms[roomName]}------`);

      
      if (rooms[roomName].length === 2) {
        const otherClient = rooms[roomName].find(id => id !== socket.id);
  
        if (otherClient) {
          io.to(otherClient).emit('ready', { otherClient: socket.id });
        }
      }
    });
  
    socket.on('offer', (data) => {
      const { roomName, offer, from } = data;
      const otherClient = rooms[roomName].find(id => id !== from);
      
      if (otherClient) {
        io.to(otherClient).emit('offer', { offer, from });
        
      }
    });
  
    socket.on('answer', (data) => {
      const { roomName, answer, from } = data;
      const otherClient = rooms[roomName].find(id => id !== from);

      if (otherClient) {
        io.to(otherClient).emit('answer', { answer, from });
      }
    });
  
    socket.on('candidate', (data) => {
      const { roomName, candidate, from } = data;
      const otherClient = rooms[roomName].find(id => id !== from);

      if (otherClient) {
        io.to(otherClient).emit('candidate', { candidate, from });
      }
    });
  
    socket.on('disconnect', () => {
      console.log('A user disconnected:', socket.id);
      for (const roomName in rooms) {
        rooms[roomName] = rooms[roomName].filter(id => id !== socket.id);
        rooms[roomName].forEach(caller => {
          io.to(caller).emit('calleeHangup');
        });
        if (rooms[roomName].length === 0) {
          delete rooms[roomName];
        }
      }
    });
  });
  
};

module.exports.getIO = () => {
  if (!io) {
    throw Error("IO not initialized.");
  }
  return io;
};
